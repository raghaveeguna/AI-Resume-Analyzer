# AI Resume Analyzer using NLP Techniques

## Project Overview

This project is an AI-powered Resume Analyzer designed to streamline the recruitment process by efficiently parsing resumes, extracting key information using Natural Language Processing (NLP) techniques, and ranking candidates against job descriptions. The system features a React-based frontend for user interaction and a FastAPI backend for handling resume processing, NLP tasks, and database operations.

## Features

- **User Authentication**: Secure email and password login/registration using Firebase.
- **Resume Upload**: Supports PDF, DOCX, and plain text resume formats.
- **Resume Parsing**: Extracts raw text from various resume formats.
- **Text Processing**: Cleans and preprocesses text (lowercase conversion, stop word removal, special character removal).
- **Keyword Extraction**: Utilizes rule-based matching, TF-IDF, and Named Entity Recognition (NER) to identify skills, technologies, and degrees.
- **Job Description Analysis**: Parses and extracts keywords from job descriptions.
- **Candidate Ranking**: Ranks resumes based on their relevance to a given job description.
- **MongoDB Integration**: Stores processed resumes and job descriptions.

## Tech Stack

### Frontend
- **React**: A JavaScript library for building user interfaces.
- **Firebase**: For user authentication (email/password) and potentially hosting.
- **React Router DOM**: For navigation within the single-page application.
- **Axios**: For making HTTP requests to the backend API.

### Backend
- **Python**: The primary language for backend logic and NLP.
- **FastAPI**: A modern, fast (high-performance) web framework for building APIs with Python 3.7+ based on standard Python type hints.
- **PyMuPDF**: For parsing PDF resumes.
- **Python-Docx**: For parsing DOCX resumes.
- **SpaCy**: For advanced NLP tasks, including tokenization and Named Entity Recognition.
- **NLTK**: For natural language processing tasks like stop word removal and tokenization.
- **Scikit-learn**: For TF-IDF vectorization and other machine learning utilities.
- **PyMongo**: The official MongoDB driver for Python.
- **Passlib**: For secure password hashing.
- **Python-Jose**: For JSON Web Token (JWT) handling.
- **python-dotenv**: For managing environment variables.

### Database
- **MongoDB Atlas**: A cloud-hosted MongoDB service for storing resume and job description data.

## Project Structure

```
/ai-resume-analyzer
├── /src
│   ├── /backend
│   │   ├── /api            # FastAPI application endpoints (main.py, auth.py)
│   │   ├── /core           # Core functionalities (e.g., database connection)
│   │   ├── /models         # Pydantic models for data validation and serialization
│   │   ├── /nlp            # NLP-related modules (resume parsing, text processing, keyword extraction)
│   │   └── /utils          # Utility functions (e.g., security, password hashing)
│   └── /frontend
│       ├── /public         # Public assets for React app
│       └── /src            # React source code
│           ├── /components # Reusable React components
│           ├── /context    # React Context API for global state (e.g., AuthContext)
│           ├── /hooks      # Custom React hooks
│           ├── /pages      # Main application pages
│           ├── /services   # API service integrations (e.g., Firebase, Backend API)
│           └── /assets     # Static assets like images
├── /docs                   # Project documentation
├── /tests                  # Unit and integration tests
├── README.md               # Project description and setup instructions
├── LICENSE                 # License file
├── .gitignore              # Git ignore file
├── requirements.txt        # Python backend dependencies
└── .env.example            # Example environment variables file
```

## Setup and Installation

### 1. Clone the Repository

```bash
git clone https://github.com/your-username/ai-resume-analyzer.git
cd ai-resume-analyzer
```

### 2. Backend Setup

Navigate to the `ai-resume-analyzer` directory.

```bash
cd ai-resume-analyzer
```

Create a virtual environment and activate it:

```bash
python3 -m venv venv
source venv/bin/activate
```

Install backend dependencies:

```bash
pip install -r requirements.txt
```

Create a `.env` file in the root directory (`ai-resume-analyzer/`) based on `.env.example` and fill in your MongoDB URI and JWT secret key:

```
MONGO_URI="your_mongodb_atlas_connection_string"
DB_NAME="resume_analyzer_db"
SECRET_KEY="your_super_secret_jwt_key"
```

Run the FastAPI application:

```bash
uvicorn src.backend.api.main:app --reload
```

The backend API will be running at `http://localhost:8000`.

### 3. Frontend Setup

Navigate to the frontend directory:

```bash
cd src/frontend
```

Install frontend dependencies:

```bash
npm install
# or yarn install
```

Configure Firebase:

Edit `src/frontend/src/services/firebase.js` with your Firebase project configuration. You will need to create a Firebase project and enable Email/Password authentication.

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "YOUR_MEASUREMENT_ID"
};
```

Run the React development server:

```bash
npm start
# or yarn start
```

The frontend application will be running at `http://localhost:3000` (or another port if 3000 is in use).

## Usage

1. **Register/Login**: Create an account or log in using the frontend application.
2. **Upload Resume**: Navigate to the "Upload Resume" page to upload PDF, DOCX, or plain text resumes. The backend will parse and store them.
3. **Analyze Job Description**: Go to the "Analyze Job Description" page, paste a job description, and analyze it to extract keywords.
4. **Rank Candidates**: Visit the "Rank Candidates" page to see how uploaded resumes rank against the latest analyzed job description.

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
